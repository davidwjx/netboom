#!/bin/bash
# install_sb.sh
#
# This is a BASH script
#
# This script checks that all packages are in place and then unpacks the nested
# archives for the SafeZone Secure Boot solution.
#

################################################################################
# Copyright (c) 2009-2018 INSIDE Secure B.V. All Rights Reserved.
#
# This confidential and proprietary software may be used only as authorized
# by a licensing agreement from INSIDE Secure.
#
# The entire notice above must be reproduced on all authorized copies that
# may only be made to the extent permitted by a licensing agreement from
# INSIDE Secure.
#
# For more information or support, please go to our online support system at
# https://essoemsupport.insidesecure.com.
# In case you do not have an account for this system, please send an e-mail to
# ESSEmbeddedHW-Support@insidesecure.com.
################################################################################

#-------------------------------------------------------------------------------
# General settings
subdir="SafeZone-Software"      # Sub directory in the install directory
zippackage="SafeZone-SecureBoot-Solution" # Package name
subpackages=""                  # Subpackage(s)
subpackages=$(echo "$subpackages SafeZone-SecureBoot_v3.8.5.tar.gz")
subpackages=$(echo "$subpackages SafeZone-SignTool_v3.8.5.tar.gz")
subpackages=$(echo "$subpackages SafeZone-TestVectors_v1.4.1.tar.gz")
topdocuments=""                 # Toplevel document(s)
topdocuments=$(echo "$topdocuments SafeZone-SecureBoot-Solution_v3.8_Getting-Started_Rev*.pdf")
documents=""                    # Document(s)
documents=$(echo "$documents SafeXcel-IP_Driver-Framework_v4.2_Porting-Guide_Rev*.pdf")
documents=$(echo "$documents SafeZone-Framework_v5.2_Porting-Guide_Rev*.pdf")
documents=$(echo "$documents SafeZone-Framework_v5.2_Reference-Manual_Rev*.pdf")
documents=$(echo "$documents SafeZone-SecureBoot-Solution_v3.8_Developer-Guide_Rev*.pdf")
documents=$(echo "$documents SafeZone-SecureBoot-Solution_v3.8_Porting-Guide-Addendum_Rev*.pdf")
documents=$(echo "$documents SafeZone-SecureBoot-Solution_v3.8_Reference-Manual_Rev*.pdf")
documents=$(echo "$documents Software-Unit-Testing-Framework_v1.1_User-Guide_Rev*.pdf")

#-------------------------------------------------------------------------------
# check_file_exists
#
# Arguments:
#  1. path to file to check.
#  2. zip file name
#
# This function checks if the given file exists. The function returns when
# the file exists. Otherwise a message is printed and the script is aborted
# with exit code 1.
#
check_file_exists()
{
    if [ ! -f "$1" ] ; then
        echo "[FATAL] Missing file $1";
        echo "        Make sure that you unzipped the $2 package.";
        exit 1;        ##### script ends here (file missing) #####
    fi
}


#-------------------------------------------------------------------------------
# Main script start

# Move to the script base directory
basedir=$(dirname $0);
cd $basedir
basedir=$(pwd)

# Check the existence of all required files
echo "[INSTALL] Step 1/3: Checking completeness..."
# - Check existence top documentation
for document in $topdocuments
do
    check_file_exists $document $zippackage
done
# - Check existence subpackages
for package in $subpackages
do
    check_file_exists $subdir/$package $zippackage
done
# - Check existence documentation
for document in $documents
do
    check_file_exists $subdir/documents/$document $zippackage
done

# Unpacking and installing all packages
echo "[INSTALL] Step 2/3: Unpacking and installing all packages..."
cd $subdir
for package in $subpackages
do
    tar zxf $package
done

# Clean-up
echo "[INSTALL] Step 3/3: Clean-up..."
for package in $subpackages
do
    rm -f $package
done
cd $basedir
rm -f install_sb.sh

echo "[INSTALL] Done!"

# end of file install_sb.sh
